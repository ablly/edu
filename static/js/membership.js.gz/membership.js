﻿// ==================== 会员管理系统 ====================

class MembershipManager {
    constructor() {
        this.tiers = [];
        this.currentUser = null;
        this.init();
    }

    async init() {
        await this.checkAuth();
        await this.loadTiers();
        this.renderPricingCards();
    }

    async checkAuth() {
        try {
            const response = await fetch('/api/auth/check');
            const data = await response.json();
            this.currentUser = data.authenticated ? data.user : null;
        } catch (error) {
            console.error('检查登录状态失败:', error);
            this.currentUser = null;
        }
    }

    async loadTiers() {
        try {
            const response = await fetch('/api/membership/tiers');
            const data = await response.json();
            this.tiers = data.tiers || [];
        } catch (error) {
            console.error('加载会员等级失败:', error);
            this.showError('加载会员方案失败，请刷新页面重试');
        }
    }

    renderPricingCards() {
        const container = document.getElementById('pricingCards');
        if (!container) return;

        if (this.tiers.length === 0) {
            container.innerHTML = `
                <div class="pricing-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>暂无可用的会员方案</p>
                </div>
            `;
            return;
        }

        container.innerHTML = this.tiers.map((tier, index) => {
            const isFeatured = tier.code === 'yearly'; // 年会员设为推荐
            const isFree = tier.code === 'free';
            
            return `
                <div class="pricing-card ${isFeatured ? 'featured' : ''}" data-tier-id="${tier.id}">
                    <div class="card-header">
                        <h3 class="tier-name">${tier.name}</h3>
                        <div class="tier-price">
                            <span class="currency">¥</span>${tier.price}
                            ${!isFree ? `<span class="period">/${this.getPeriodText(tier.code)}</span>` : ''}
                        </div>
                        <p class="tier-description">${tier.description || ''}</p>
                    </div>
                    
                    <ul class="features-list">
                        ${this.renderFeatures(tier.features)}
                    </ul>
                    
                    <button 
                        class="purchase-button ${isFree ? 'btn-free' : 'btn-buy'}"
                        onclick="membershipManager.handlePurchase('${tier.code}', ${tier.id})"
                        ${isFree ? 'disabled' : ''}
                    >
                        <i class="fas ${isFree ? 'fa-check' : 'fa-shopping-cart'}"></i>
                        <span>${isFree ? '当前方案' : '立即购买'}</span>
                    </button>
                </div>
            `;
        }).join('');
    }

    getPeriodText(code) {
        const periods = {
            'weekly': '周',
            'monthly': '月',
            'yearly': '年'
        };
        return periods[code] || '';
    }

    renderFeatures(featuresJson) {
        try {
            const features = typeof featuresJson === 'string' ? JSON.parse(featuresJson) : featuresJson;
            if (!Array.isArray(features)) return '';
            
            // 限制最多显示5个功能
            const displayFeatures = features.slice(0, 5);
            
            return displayFeatures.map(feature => `
                <li class="feature-item">
                    <i class="fas fa-check-circle"></i>
                    <span>${feature}</span>
                </li>
            `).join('');
        } catch (error) {
            console.error('解析功能列表失败:', error);
            return '';
        }
    }

    async handlePurchase(tierCode, tierId) {
        // 检查是否登录
        if (!this.currentUser) {
            this.showToast('请先登录', '请登录后再购买会员', 'warning');
            setTimeout(() => {
                window.location.href = '/login';
            }, 1500);
            return;
        }

        // 确认购买
        if (!confirm(`确认购买${this.getTierName(tierCode)}？`)) {
            return;
        }

        // 显示加载状态
        const button = event.target.closest('button');
        const originalContent = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 处理中...';

        try {
            // 调用模拟支付API
            const response = await fetch('/api/membership/purchase', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    tier_id: tierId
                })
            });

            const data = await response.json();

            if (response.ok) {
                this.showToast('购买成功', '会员已激活，开始享受服务吧！', 'success');
                
                // 延迟刷新页面
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            } else {
                throw new Error(data.error || '购买失败');
            }
        } catch (error) {
            console.error('购买失败:', error);
            this.showToast('购买失败', error.message, 'error');
            button.disabled = false;
            button.innerHTML = originalContent;
        }
    }

    getTierName(code) {
        const names = {
            'free': '免费用户',
            'weekly': '周会员',
            'monthly': '月会员',
            'yearly': '年会员'
        };
        return names[code] || '会员';
    }

    showToast(title, message, type = 'info') {
        // 创建toast容器（如果不存在）
        let container = document.getElementById('toast-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toast-container';
            container.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 10000;
                display: flex;
                flex-direction: column;
                gap: 10px;
            `;
            document.body.appendChild(container);
        }

        // 创建toast
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.style.cssText = `
            min-width: 300px;
            padding: 16px 20px;
            border-radius: 10px;
            background: white;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
        `;

        const iconClass = {
            'success': 'fa-check-circle',
            'error': 'fa-exclamation-circle',
            'warning': 'fa-exclamation-triangle',
            'info': 'fa-info-circle'
        }[type] || 'fa-info-circle';

        const iconColor = {
            'success': '#10b981',
            'error': '#ef4444',
            'warning': '#f59e0b',
            'info': '#3b82f6'
        }[type] || '#3b82f6';

        toast.innerHTML = `
            <i class="fas ${iconClass}" style="color: ${iconColor}; font-size: 20px;"></i>
            <div style="flex: 1;">
                <div style="font-weight: 600; margin-bottom: 4px;">${title}</div>
                <div style="font-size: 14px; color: #6b7280;">${message}</div>
            </div>
        `;

        container.appendChild(toast);

        // 3秒后移除
        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    showError(message) {
        const container = document.getElementById('pricingCards');
        if (container) {
            container.innerHTML = `
                <div class="pricing-error" style="grid-column: 1 / -1; text-align: center; color: white; padding: 40px;">
                    <i class="fas fa-exclamation-circle" style="font-size: 48px; margin-bottom: 16px;"></i>
                    <p style="font-size: 18px;">${message}</p>
                </div>
            `;
        }
    }
}

// 初始化
let membershipManager;
document.addEventListener('DOMContentLoaded', () => {
    membershipManager = new MembershipManager();
});

// CSS动画
(function() {
    const membershipStyle = document.createElement('style');
    membershipStyle.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(400px);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(membershipStyle);
})();

// CSS鍔ㄧ敾
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

